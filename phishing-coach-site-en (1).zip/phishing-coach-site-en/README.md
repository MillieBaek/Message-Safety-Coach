# Message Safety Coach

A coach that helps people vulnerable to scams (including seniors) understand suspicious texts and emails. Paste a message and it flags risk level, highlights risky sentences, and tells you what to do next.

## Structure
- `public/index.html` — frontend (static, no build step needed)
- `api/analyze.js` — Vercel serverless function that calls the Anthropic API server-side, so the API key is never exposed in the browser
- `.env.example` — example environment variable

## Deploying (Vercel, free)

1. **Get an Anthropic API key**
   Sign in at https://console.anthropic.com and create an API key.

2. **Create a GitHub repository**
   Upload this whole folder to a new GitHub repo (GitHub Desktop works with no command line needed).
   ```bash
   git init
   git add .
   git commit -m "message safety coach initial commit"
   git remote add origin https://github.com/your-username/your-repo.git
   git push -u origin main
   ```

3. **Connect to Vercel**
   Go to https://vercel.com, sign in with GitHub → "Add New Project" → select this repo → Import.
   Leave the default build settings — Vercel auto-detects the static frontend and serverless function.

4. **Set the environment variable**
   In your Vercel project → Settings → Environment Variables, add
   `ANTHROPIC_API_KEY` = your API key (check both Production and Preview).

5. **Deploy**
   Click Deploy. Within a minute or two you'll get a live URL like `https://your-project.vercel.app`.
   Every push to GitHub after this will auto-redeploy.

## Testing locally
```bash
npm install -g vercel
vercel dev
```
Copy `.env.example` to `.env` and add your real API key first.

## Ideas for next steps
- Validate accuracy against a dataset of real phishing examples
- Test with 3–5 real users and refine wording/category names based on their feedback
- Add rate limiting or caching to manage API costs
